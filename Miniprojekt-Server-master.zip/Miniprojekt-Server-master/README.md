# Miniprojekt-Server

Installieren der Dependencies mit

```$ npm install ```

und ausführen:

```$ node server.js```

Der Server hört auf Port 8080. Alternativ steht auch ein Docker-Container bereit den Sie stattdessen einsetzen können:

```$ docker run --rm -t -i -p 8080:8080 misto/miniprojekt-server```
